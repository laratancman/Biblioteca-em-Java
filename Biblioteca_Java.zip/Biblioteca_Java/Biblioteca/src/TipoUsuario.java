// Enum para definir os tipos de usuário
public enum TipoUsuario {
    ALUNO,
    PROFESSOR
}
